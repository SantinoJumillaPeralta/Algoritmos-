#ifndef BRIDGE_H
#define BRIDGE_H

#include "raylib.h"
#include <box2d.h>
#include <vector>

struct BridgePiece
{
    b2Body* body;
    float width;
    float height;
    Color color;
};

void CreateBridge(
    b2World& world,
    std::vector<BridgePiece>& bridgePieces,
    b2Body*& leftSupport,
    b2Body*& rightSupport,
    b2Body*& leftAnchor,
    b2Body*& rightAnchor
);

void DrawBridge(const std::vector<BridgePiece>& bridgePieces);

#endif
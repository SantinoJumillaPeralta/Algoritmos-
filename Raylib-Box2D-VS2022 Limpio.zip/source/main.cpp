#ifndef NDEBUG
#include <vld.h>
#endif

#include "Game.h"

int main(void)
{
    GameState game;
    InitGame(game);

    while (!WindowShouldClose())
    {
        UpdateGame(game);
        BeginDrawing();
        DrawGame(game);
        EndDrawing();
    }

    UnloadGame(game);
    return 0;
}
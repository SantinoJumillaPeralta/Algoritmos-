#ifndef GAME_H
#define GAME_H

#include "raylib.h"
#include <box2d.h>
#include <vector>
#include "Bridge.h"

struct FallingBox
{
    b2Body* body;
    float size;
    Color color;
};

struct GameState
{
    int screenWidth;
    int screenHeight;

    Color fondo;
    Color textoPrincipal;
    Color textoSecundario;
    Color sueloColor;

    b2World* world;

    std::vector<BridgePiece> bridgePieces;
    std::vector<FallingBox> boxes;

    b2Body* groundBody;
    b2Body* leftSupport;
    b2Body* rightSupport;
    b2Body* leftAnchor;
    b2Body* rightAnchor;
};

void InitGame(GameState& game);
void UpdateGame(GameState& game);
void DrawGame(const GameState& game);
void UnloadGame(GameState& game);

#endif
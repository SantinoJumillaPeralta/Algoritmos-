#include "Bridge.h"

static Vector2 GetParabolaPoint(Vector2 a, Vector2 b, float t, float sag)
{
    float x = a.x + (b.x - a.x) * t;
    float yBase = a.y + (b.y - a.y) * t;
    float curve = 4.0f * sag * t * (1.0f - t);
    return { x, yBase + curve };
}

void CreateBridge(
    b2World& world,
    std::vector<BridgePiece>& bridgePieces,
    b2Body*& leftSupport,
    b2Body*& rightSupport,
    b2Body*& leftAnchor,
    b2Body*& rightAnchor
)
{
    Color puenteColor = Fade(BROWN, 0.95f);

    b2BodyDef leftSupportDef;
    leftSupportDef.type = b2_staticBody;
    leftSupportDef.position.Set(180.0f, 320.0f);
    leftSupport = world.CreateBody(&leftSupportDef);

    b2PolygonShape supportShape;
    supportShape.SetAsBox(18.0f, 120.0f);
    leftSupport->CreateFixture(&supportShape, 0.0f);

    b2BodyDef rightSupportDef;
    rightSupportDef.type = b2_staticBody;
    rightSupportDef.position.Set(820.0f, 320.0f);
    rightSupport = world.CreateBody(&rightSupportDef);
    rightSupport->CreateFixture(&supportShape, 0.0f);

    b2BodyDef leftAnchorDef;
    leftAnchorDef.type = b2_staticBody;
    leftAnchorDef.position.Set(180.0f, 160.0f);
    leftAnchor = world.CreateBody(&leftAnchorDef);

    b2BodyDef rightAnchorDef;
    rightAnchorDef.type = b2_staticBody;
    rightAnchorDef.position.Set(820.0f, 160.0f);
    rightAnchor = world.CreateBody(&rightAnchorDef);

    const int pieceCount = 14;
    const float pieceWidth = 52.0f;
    const float pieceHeight = 18.0f;
    const float startX = 210.0f;
    const float stepX = 45.0f;
    const float baseY = 390.0f;

    b2Body* previousPiece = nullptr;

    for (int i = 0; i < pieceCount; i++)
    {
        b2BodyDef pieceDef;
        pieceDef.type = b2_dynamicBody;
        pieceDef.position.Set(startX + i * stepX, baseY);
        pieceDef.angle = 0.0f;
        pieceDef.angularDamping = 1.2f;

        b2Body* pieceBody = world.CreateBody(&pieceDef);

        b2PolygonShape pieceShape;
        pieceShape.SetAsBox(pieceWidth / 2.0f, pieceHeight / 2.0f);

        b2FixtureDef pieceFixture;
        pieceFixture.shape = &pieceShape;
        pieceFixture.density = 1.0f;
        pieceFixture.friction = 0.9f;
        pieceFixture.restitution = 0.05f;

        pieceBody->CreateFixture(&pieceFixture);

        bridgePieces.push_back({ pieceBody, pieceWidth, pieceHeight, puenteColor });

        if (previousPiece != nullptr)
        {
            b2RevoluteJointDef revDef;
            revDef.Initialize(previousPiece, pieceBody, b2Vec2(startX + (i - 1) * stepX + stepX / 2.0f, baseY));
            revDef.enableLimit = true;
            revDef.lowerAngle = -0.18f;
            revDef.upperAngle = 0.18f;
            world.CreateJoint(&revDef);
        }

        previousPiece = pieceBody;
    }

    {
        b2RevoluteJointDef leftEndJoint;
        leftEndJoint.Initialize(leftSupport, bridgePieces.front().body, b2Vec2(startX - stepX / 2.0f, baseY));
        leftEndJoint.enableLimit = true;
        leftEndJoint.lowerAngle = -0.06f;
        leftEndJoint.upperAngle = 0.06f;
        world.CreateJoint(&leftEndJoint);
    }

    {
        b2RevoluteJointDef rightEndJoint;
        rightEndJoint.Initialize(bridgePieces.back().body, rightSupport, b2Vec2(startX + (pieceCount - 1) * stepX + stepX / 2.0f, baseY));
        rightEndJoint.enableLimit = true;
        rightEndJoint.lowerAngle = -0.06f;
        rightEndJoint.upperAngle = 0.06f;
        world.CreateJoint(&rightEndJoint);
    }

    {
        b2DistanceJointDef ropeLeft;
        ropeLeft.Initialize(
            leftAnchor,
            bridgePieces.front().body,
            leftAnchorDef.position,
            bridgePieces.front().body->GetWorldPoint(b2Vec2(-pieceWidth / 2.0f, 0.0f))
        );
        ropeLeft.stiffness = 10.0f;
        ropeLeft.damping = 0.7f;
        ropeLeft.collideConnected = false;
        world.CreateJoint(&ropeLeft);
    }

    {
        b2DistanceJointDef ropeRight;
        ropeRight.Initialize(
            rightAnchor,
            bridgePieces.back().body,
            rightAnchorDef.position,
            bridgePieces.back().body->GetWorldPoint(b2Vec2(pieceWidth / 2.0f, 0.0f))
        );
        ropeRight.stiffness = 10.0f;
        ropeRight.damping = 0.7f;
        ropeRight.collideConnected = false;
        world.CreateJoint(&ropeRight);
    }
}

void DrawBridge(const std::vector<BridgePiece>& bridgePieces)
{
    Vector2 leftTop = { 180.0f, 160.0f };
    Vector2 rightTop = { 820.0f, 160.0f };

    Vector2 prevTopPoint = leftTop;
    int ropeSegments = 24;

    for (int i = 1; i <= ropeSegments; i++)
    {
        float t = (float)i / (float)ropeSegments;
        Vector2 topPoint = GetParabolaPoint(leftTop, rightTop, t, 35.0f);
        DrawLineEx(prevTopPoint, topPoint, 4.0f, BEIGE);
        prevTopPoint = topPoint;
    }

    for (int i = 0; i < (int)bridgePieces.size(); i++)
    {
        float t = (bridgePieces.size() <= 1) ? 0.0f : (float)i / (float)(bridgePieces.size() - 1);
        Vector2 topPoint = GetParabolaPoint(leftTop, rightTop, t, 35.0f);

        b2Vec2 p = bridgePieces[i].body->GetPosition();
        Vector2 bottomPoint = { p.x, p.y - bridgePieces[i].height / 2.0f };

        DrawLineEx(topPoint, bottomPoint, 2.0f, Fade(BEIGE, 0.95f));
    }

    for (const auto& piece : bridgePieces)
    {
        b2Vec2 pos = piece.body->GetPosition();
        float angle = piece.body->GetAngle() * RAD2DEG;

        Rectangle rect = {
            pos.x - piece.width / 2.0f,
            pos.y - piece.height / 2.0f,
            piece.width,
            piece.height
        };

        Vector2 origin = { piece.width / 2.0f, piece.height / 2.0f };
        DrawRectanglePro(rect, origin, angle, piece.color);
        DrawRectangleLinesEx(rect, 2, DARKBROWN);
    }

    for (int i = 0; i < (int)bridgePieces.size() - 1; i++)
    {
        b2Vec2 a = bridgePieces[i].body->GetPosition();
        b2Vec2 b = bridgePieces[i + 1].body->GetPosition();

        DrawLineEx({ a.x + 20.0f, a.y }, { b.x - 20.0f, b.y }, 1.0f, Fade(DARKBROWN, 0.7f));
    }

    DrawCircleV(leftTop, 8.0f, DARKGRAY);
    DrawCircleV(rightTop, 8.0f, DARKGRAY);
}
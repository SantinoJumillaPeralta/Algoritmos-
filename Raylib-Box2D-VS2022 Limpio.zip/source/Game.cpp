#include "Game.h"

static void CreateFallingBox(GameState& game, float x, float y)
{
    b2BodyDef boxDef;
    boxDef.type = b2_dynamicBody;
    boxDef.position.Set(x, y);

    b2Body* boxBody = game.world->CreateBody(&boxDef);

    b2PolygonShape boxShape;
    boxShape.SetAsBox(20.0f, 20.0f);

    b2FixtureDef boxFixture;
    boxFixture.shape = &boxShape;
    boxFixture.density = 1.0f;
    boxFixture.friction = 0.5f;
    boxFixture.restitution = 0.1f;

    boxBody->CreateFixture(&boxFixture);

    game.boxes.push_back({ boxBody, 40.0f, Fade(ORANGE, 0.95f) });
}

static void DrawFallingBoxes(const std::vector<FallingBox>& boxes)
{
    for (const auto& box : boxes)
    {
        b2Vec2 pos = box.body->GetPosition();
        float angle = box.body->GetAngle() * RAD2DEG;

        Rectangle rect = {
            pos.x - box.size / 2.0f,
            pos.y - box.size / 2.0f,
            box.size,
            box.size
        };

        Vector2 origin = { box.size / 2.0f, box.size / 2.0f };
        DrawRectanglePro(rect, origin, angle, box.color);
        DrawRectangleLinesEx(rect, 2, BROWN);
    }
}

void InitGame(GameState& game)
{
    game.screenWidth = 1000;
    game.screenHeight = 600;

    InitWindow(game.screenWidth, game.screenHeight, "MAVI II - Puente fisico");
    SetTargetFPS(60);

    game.fondo = { 110, 100, 215, 255 };
    game.textoPrincipal = RAYWHITE;
    game.textoSecundario = DARKPURPLE;
    game.sueloColor = Fade(DARKGREEN, 0.7f);

    b2Vec2 gravity(0.0f, 9.8f);
    game.world = new b2World(gravity);

    game.groundBody = nullptr;
    game.leftSupport = nullptr;
    game.rightSupport = nullptr;
    game.leftAnchor = nullptr;
    game.rightAnchor = nullptr;

    b2BodyDef groundDef;
    groundDef.type = b2_staticBody;
    groundDef.position.Set(game.screenWidth / 2.0f, game.screenHeight - 40.0f);
    game.groundBody = game.world->CreateBody(&groundDef);

    b2PolygonShape groundShape;
    groundShape.SetAsBox(game.screenWidth / 2.0f, 20.0f);
    game.groundBody->CreateFixture(&groundShape, 0.0f);

    CreateBridge(*game.world, game.bridgePieces, game.leftSupport, game.rightSupport, game.leftAnchor, game.rightAnchor);

    CreateFallingBox(game, 500.0f, 90.0f);
}

void UpdateGame(GameState& game)
{
    if (IsKeyPressed(KEY_SPACE))
    {
        CreateFallingBox(game, 500.0f, 90.0f);
    }

    game.world->Step(1.0f / 60.0f, 8, 3);
}

void DrawGame(const GameState& game)
{
    ClearBackground(game.fondo);

    DrawRectangle(0, game.screenHeight - 60, game.screenWidth, 40, game.sueloColor);

    DrawRectangle(162, 200, 36, 240, Fade(DARKBROWN, 0.95f));
    DrawRectangle(802, 200, 36, 240, Fade(DARKBROWN, 0.95f));
    DrawRectangle(150, 150, 60, 18, Fade(DARKBROWN, 0.95f));
    DrawRectangle(790, 150, 60, 18, Fade(DARKBROWN, 0.95f));

    DrawBridge(game.bridgePieces);

    DrawFallingBoxes(game.boxes);

    DrawRectangle(90, 70, 820, 90, Fade(BLACK, 0.18f));
    DrawText("Puente fisico con joints", 330, 90, 28, game.textoPrincipal);
    DrawText("Revolute Joint + Distance Joint", 320, 125, 22, game.textoSecundario);
    DrawText("ESPACIO: soltar otra caja", 355, 150, 18, RAYWHITE);

    DrawText("Sistema fisico compuesto en Box2D", 340, 540, 20, RAYWHITE);
}

void UnloadGame(GameState& game)
{
    CloseWindow();

    delete game.world;
    game.world = nullptr;
}